function [] = run_project()
%Set the Paramaters from m-file:
Parameters;

%Run Questions 1 to 5
[t, y, v, h, A , Total_Distance] = modeuler_bungee(T, n, g, C, K, L, H, D, m);
%%
%Question 6

%Made a new m-file called Question_6_bungee, an exact copy (as far as coding goes)
%of how Question 1 was completed in modeuler_bungee

%Question_6_bungee(T, n, g, C, K, L+74-max(y), H, D)
%The above line descends the jumper too far, for obvious reason (so it's
%clear that it's not as simple as extending the rope by the 20ish metres 
%above the water the jumper is)

%Use a bisection-type method on the length of the rope to get the
%jumper to get the jumper's lowest point to be at water level (could also
%go by trial and error, but a bisection-type method is more robust)

%To find an ideal L or K value
[ideal_L, ideal_K, ideal_k, whichVal] = Question_6_bisection(T, n, g, C, K, L, H, y, m);

%Tell the user which parameter/s to change and to which value/s
if whichVal == 'L'
    ideal_L_for_water_touch = ideal_L
    ['Leave k and K as is (' num2str(k) ' and ' num2str(K) ' respectively).']
elseif whichVal == 'K'
    ideal_k_for_water_touch = ideal_k
    ideal_K_for_water_touch = ideal_K
    ['Leave L as is (' num2str(L) ' metres).']
else
    ideal_L_for_water_touch = ideal_L
    ideal_k_for_water_touch = ideal_k
    ideal_K_for_water_touch = ideal_K
end

%Draw the graph of the jumper against time with the new parameters:
[t, y, v, h, max_gforces] = Question_6_bungee(T, n, g, C, ideal_K, ideal_L);
figure(4)
plot(t, H-y, 'b'); %% 74=H, height
hold on
plot(t, t*0+H, 'c'); %% 74=H, to show height of platform
xlabel('Time (s)');
ylabel('Jumper''s Height Above Water (m)') %% height
title_string = ['Figure 4: Plot of Jumper''s Height Above Water (With k = ' num2str(ideal_k) ' N/m, K = ' num2str(ideal_K) 'm^-1 and L = ' num2str(ideal_L) ' m)'];
title(title_string) %% height
legend('Jumper''s Height (m)', 'Platform Height (m)')
max_g_forces_with_water_touch = max_gforces
num_of_bounces_with_water_touch = find_number_of_bounces(n, g, C, ideal_K, ideal_L)
end
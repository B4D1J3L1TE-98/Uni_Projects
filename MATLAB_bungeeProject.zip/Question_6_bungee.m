function [t, y, v, h, max_gforces] = Question_6_bungee(T, n, g, C, K, L)
% [t, y, v, h] = Question_6(T, n, g, C, K, L) performs Euler's method on
% the bungee jumping model, taking n steps from t = 0 to t = T.
% The initial conditions are y(0) = 0 and v(0) = 0.
% The inputs g, C, K and L are parameters from the model (see project description).
% g is the acceleration due to gravity (i.e. 9.8)
% m is the mass of the jumper (not necessary here, but explains C and K)
% C = c/m, where c is the drag coefficient when moving through the air
% K = k/m, where k is the spring constant of the bungee rope/cord
% L is the length of the rope
% The outputs are the time array t, the solution arrays y and v, the
% subinterval width h, and the maximum acceleration expressed by the jumper
% in g's max_gforces

%FROM Question 1
% Calculate subinterval width h
h = T / n;

% Create time array t
t = 0:h:T;

% Initialise solution arrays y and v
y = zeros(1,n+1);
v = zeros(1,n+1);

% perform iterations
for j = 1:n
    %%%  f(t(j), w(j)) becomes the expression for acceleration
    %%%  (g - C*abs(v(j))*v(j) - max(0, K*(y(j) - L))):
    k1 = h*(g - C*abs(v(j))*v(j) - max(0, K*(y(j) - L)));
    
    %%%  substitute (v(j)+k1) for all (v(j)) because k2=f(t(j) + h, w(j) + k1), 
    %%%  so basically turning (w(j)) into (w(j)+k1) [the time array doesn't
    %%%  affect this]
    k2 = h*(g - C*(abs(v(j)+k1))*(v(j)+k1) - max(0, K*((y(j)) - L)));
    v(j+1) = v(j) + 1/2 * (k1 + k2);
    
    %%% the expression for y also changes
    %%% use formula: y(i+1)=y(i)+(h/2)[f(t(i), y(i))+f(t(i+1), y(i+1))]
             yk1 = v(j);
             yk2 = v(j+ 1);
             y(j+1) = y(j) + ((h/2) * (yk1 + yk2));
end

%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_
%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

%FROM Question 3 
%numerical differentiation 
A_Q6 = zeros(1,n+1);
A_Q6(1) = 0 ;
for i = 2 : n 
    A_Q6(i) = (v(i+1) -  v(i-1)) / (2*h); %approximation for Acceleration, See chapter 5 
%approximating third derivative will require approximation of a further
%derivative, so we must accept an error of [ ((h^2)/6)*(f'''(c)) ]
end

maximum_positive_acceleration = max(A_Q6);
maximum_negative_acceleration = min(A_Q6);
if abs(maximum_positive_acceleration) - abs(maximum_negative_acceleration) < 0 %if the maximum negative acceleration is greater in magnitude than the maximum positive acceleration
    max_gforces = (abs(maximum_negative_acceleration))/(9.8); %calculate the maximum gforce
else %if the maximum positive acceleration is greater in magnitude than the maximum negative acceleration
    max_gforces = (abs(maximum_positive_acceleration))/(9.8); %calculate the maximum gforce
end

end
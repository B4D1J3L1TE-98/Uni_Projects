function K_value = Question_6_find_K_for_L(T, n, g, C, start_K, end_K, ideal_L, H, max_y_goal) 
% K_value = Question_6_find_K_for_L(T, n, g, C, start_K, ideal_L, H, max_y_goal, end_K)
% uses a bisection method to find the K value that pairs with a given L
% value to achieve a given maximum goal for the y value when running
% Question_6_bungee

%The input ideal_L is used as the L value for Question_6_bungee
%Inputs start_K and end_K are the minimum and maximum values for the K_value
%output to be
%The input max_y_goal is the goal value for the highest y value in the y
%solution array in Question_6_bungee
%The output is K_value, which, when used with T,n,g,C,~,ideal_L,H as
%parameters for Question_6_bungee, will achieve a maximum y value output of
%the max_y_goal

%(T, n, g, C, K, L) are the values necessary to run Question_6_bungee:
% [t, y, v, h, max_g_forces] = Question_6_bungee(T, n, g, C, K, L) performs Euler's method on
% the bungee jumping model, taking n steps from t = 0 to t = T.
% The initial conditions are y(0) = 0 and v(0) = 0.
% The inputs g, C, K and L are parameters from the model (see project description).
% g is the acceleration due to gravity (i.e. 9.8)
% m is the mass of the jumper (not necessary here, but explains C and K)
% C = c/m, where c is the drag coefficient when moving through the air
% K = k/m, where k is the spring constant of the bungee rope/cord
% L is the length of the rope
% The outputs are the time array t, the solution arrays y and v, the
% subinterval width h, and the maximum number of g-forces experienced by
% the jumper max_g_forces


%bisection method to find K for this ideal_L:
    ideal_K = (start_K + end_K) / 2;
    %(start_K, end_K) will bracket the solution to begin with as their
    %starting values are the matching K values for the L value limits
    while (ideal_K ~= end_K) && (ideal_K ~= start_K)
        %Run the Question_6_bungee function to find the maximum y value for
        %each value of K
        [~, y_start, ~, ~] = Question_6_bungee(T, n, g, C, start_K, ideal_L);
        [~, y_ideal, ~, ~] = Question_6_bungee(T, n, g, C, ideal_K, ideal_L);
    
        if sign(max_y_goal - max(y_ideal)) == sign(max_y_goal - max(y_start))
        %^if the maximum y using the current ideal_K value is on the same
        %^side of the goal for max_y as the maximum y using the current
        %^start_K value
            start_K = ideal_K;
        else
            end_K = ideal_K;
        end
            ideal_K = (start_K + end_K)/2; %calculate new ideal_K value
    end
    K_value = ideal_K;
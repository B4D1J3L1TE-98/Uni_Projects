function [ideal_L, ideal_K] = Question_6_find_best_L(T, n, g, C, start_L, end_L, H, max_y_goal, goal_bounces, bounce_tolerance, max_g_max, g_change_same, b_change_same, start_K, end_K)
%function [min_L, max_L] = Question_6_find_L_boundaries(T, n, g, C, K, L, H, max_y_goal, goal_bounces, bounce_tolerance, max_g_max, g_change_same, b_change_same, start_K, end_K)
%finds the minimum and maximum L values such that the number of bounces
%experienced by the bungee jumper in the model are within bounce_tolerance
%of goal_bounces, then uses the bisection method to find the best values of
%L and K to achieve the best number of g forces (as big as possible, while
%below 2) within the tolerated number of bounces

%max_y_goal is the goal value for the maximum value in the y solution array
%when running Question_6_bungee with all the parameters
%goal_bounces is the goal number of bounces (said on the task sheet to be
%10)
%bounce_tolerance is the tolerance on the number of bounces (eg. a
%tolerance of 0 means there must be exactly 10 bounces, a tolerance of 1
%allows for 9-11 bounces, a tolerance of 2 allows for 8-12 bounces, etc.)
%max_g_max is the maximum number of g forces allowed to be experienced by
%the jumper (this is 2 for safety reasons)
%g_change_same is whether or not the number of g's experienced increases as
%L increases
%b_change_same is whether or not the number of bounces in the jump 
%increases as L increases
%start_L and end_L are the smallest and largest possible values of L that
%are available
%start_K and end_K are the smallest and largest possible values of K that
%can be used (these are used to call Question_6_find_K_for_L) 

%(n, g, C, K, L) are the values necessary to run Question_6_bungee
%and find_number_of_bounces:
% [t, y, v, h, max_g_forces] = Question_6_bungee(T, n, g, C, K, L) performs Euler's method on
% the bungee jumping model, taking n steps from t = 0 to t = T.
% The initial conditions are y(0) = 0 and v(0) = 0.
% The inputs g, C, K and L are parameters from the model (see project description).
% g is the acceleration due to gravity (i.e. 9.8)
% m is the mass of the jumper (not necessary here, but explains C and K)
% C = c/m, where c is the drag coefficient when moving through the air
% K = k/m, where k is the spring constant of the bungee rope/cord. This
% will be found by calling  Question_6_find_K_for_L
% L is the length of the rope
% The outputs are the time array t, the solution arrays y and v, the
% subinterval width h, and the maximum number of g-forces experienced by
% the jumper max_g_forces
% % % % % start_L, end_L, start_K, end_K
if b_change_same == 1
    %bisect to find smallest L such that
    %bounces >= goal_bounces - bounce_tolerance
    a_L_max = start_L;
    b_L_max = end_L;
    p_L_max = (start_L + end_L) / 2;
    while (p_L_max ~= a_L_max) && (p_L_max ~= b_L_max)
        K_value = Question_6_find_K_for_L(T, n, g, C, start_K, end_K, p_L_max, H, max_y_goal);
        p_bounces = find_number_of_bounces(n, g, C, K_value, p_L_max);
        if p_bounces >= goal_bounces - bounce_tolerance
            b_L_max = p_L_max;
        else
            a_L_max = p_L_max;
        end
        p_L_max = (a_L_max + b_L_max)/2; %calculate new p value
    end
    %bisect to find largest L such that
    %bounces <= goal_bounces + bounce_tolerance
    a_L_min = start_L;
    b_L_min = end_L;
    p_L_min = (start_L + end_L) / 2;
    while (p_L_min ~= a_L_min) && (p_L_min ~= b_L_min)
        K_value = Question_6_find_K_for_L(T, n, g, C, start_K, end_K, p_L_min, H, max_y_goal);
        p_bounces = find_number_of_bounces(n, g, C, K_value, p_L_min);
        if p_bounces <= goal_bounces + bounce_tolerance
            a_L_min = p_L_min;
        else
            b_L_min = p_L_min;
        end
        p_L_min = (a_L_min + b_L_min)/2; %calculate new p value
    end
else
    %bisect to find largest L such that
    %bounces >= goal_bounces - bounce_tolerance
    a_L_max = start_L;
    b_L_max = end_L;
    p_L_max = (start_L + end_L) / 2;
    while (p_L_max ~= a_L_max) && (p_L_max ~= b_L_max)
        K_value = Question_6_find_K_for_L(T, n, g, C, start_K, end_K, p_L_max, H, max_y_goal);
% % % % %         K_value, p_L_max
        p_bounces = find_number_of_bounces(n, g, C, K_value, p_L_max);
        if p_bounces >= goal_bounces - bounce_tolerance
            a_L_max = p_L_max;
        else
            b_L_max = p_L_max;
        end
        p_L_max = (a_L_max + b_L_max)/2; %calculate new p value
    end
    %bisect to find smallest L such that
    %bounces <= goal_bounces + bounce_tolerance
    a_L_min = start_L;
    b_L_min = end_L;
    p_L_min = (start_L + end_L) / 2;
    while (p_L_min ~= a_L_min) && (p_L_min ~= b_L_min)
        K_value = Question_6_find_K_for_L(T, n, g, C, start_K, end_K, p_L_min, H, max_y_goal);
        p_bounces = find_number_of_bounces(n, g, C, K_value, p_L_min);
        if p_bounces <= goal_bounces + bounce_tolerance
            b_L_min = p_L_min;
        else
            a_L_min = p_L_min;
        end
        p_L_min = (a_L_min + b_L_min)/2; %calculate new p value
    end
end
if g_change_same == 1
    %bisect to find largest L such that
    %max_g < 2
    a_L_g = start_L;
    b_L_g = end_L;
    p_L_g = (start_L + end_L) / 2;
    while (p_L_g ~= a_L_g) && (p_L_g ~= b_L_g)
        K_value = Question_6_find_K_for_L(T, n, g, C, start_K, end_K, p_L_g, H, max_y_goal);
        [~, ~, ~, ~, p_max_g] = Question_6_bungee(T, n, g, C, K_value, p_L_g);
        if p_max_g < max_g_max
            a_L_g = p_L_g;
        else
            b_L_g = p_L_g;
        end
        p_L_g = (a_L_g + b_L_g)/2; %calculate new p value
    end
else
    %bisect to find smallest L such that
    %max_g < 2
    a_L_g = start_L;
    b_L_g = end_L;
    p_L_g = (start_L + end_L) / 2;
    while (p_L_g ~= a_L_g) && (p_L_g ~= b_L_g)
        K_value = Question_6_find_K_for_L(T, n, g, C, start_K, end_K, p_L_g, H, max_y_goal);
        [~, ~, ~, ~, p_max_g] = Question_6_bungee(T, n, g, C, K_value, p_L_g);
        if p_max_g < max_g_max
            b_L_g = p_L_g;
        else
            a_L_g = p_L_g;
        end
        p_L_g = (a_L_g + b_L_g)/2; %calculate new p value
    end
end

%All considerable values of L fall between the largest minimum and smallest
%maximum (inclusive). If g increases as L increases, the best L value (with
%its corresponding K) is at the smallest maximum. If g decreases when L
%increases, then the best L value (with corresponding K) is at the largest
%minimum.
if g_change_same == 1
    ideal_L = min(p_L_g, p_L_max); %p_L_g is a max value for L here
    ideal_K = Question_6_find_K_for_L(T, n, g, C, start_K, end_K, ideal_L, H, max_y_goal);
else
    ideal_L = max(p_L_g, p_L_min); %p_L_g is a min value for L here
    ideal_K = Question_6_find_K_for_L(T, n, g, C, start_K, end_K, ideal_L, H, max_y_goal);
end

end
function [ideal_L, ideal_K] = Question_6_change_both_values(T, n, g, C, K, L, H, max_y_goal, L_lim, K_lim)
%FUNCTION [IDEAL_L, IDEAL_K] = Question_6_change_both_values(T, n, g, C, K,
%L, H, max_y_goal, L_lim, K_lim, changeVal) returns the ideal L and K
%values to introduce a water touch experience to the bungee jumping model
%Changing the L and K values for the model to this ideal_L and ideal_K will
%produce a water touch experience
%
%Input max_y_goal is the goal value for max(y). Achieving this value for
% max(y) means a water touch experience is achieved
%
%L_lim is the ideal_L value if ideal_K was not going to change
%K_lim is the ideal_K value if ideal_L was not going to change
%Both are being changed here, and this information will be helpful in
%determining the true ideal L and K values
%
%(T, n, g, C, K, L, H) are the values necessary to run Question_6_bungee:
% [t, y, v, h, max_g_forces] = Question_6_bungee(T, n, g, C, K, L) performs Euler's method on
% the bungee jumping model, taking n steps from t = 0 to t = T.
% The initial conditions are y(0) = 0 and v(0) = 0.
% The inputs g, C, K and L are parameters from the model (see project description).
% The outputs are the time array t, the solution arrays y and v, the
% subinterval width h, and the maximum number of g-forces experienced by
% the jumper max_g_forces

%First, figure out whether L>L_lim and whether K > K_lim
if L > L_lim
    start_L = L_lim;
    end_L = L;
else %if L < L_lim, as L = L_lim is accounted for in Question_6_bisection
    start_L = L;
    end_L = L_lim;
end
if K > K_lim
    start_K = K_lim;
    end_K = K;
else %if K < K_lim, as K = K_lim is accounted for in Question_6_bisection
    start_K = K;
    end_K = K_lim;
end
    
goal_bounces = 10; %goal number of bounces
bounce_tolerance = 0; 
%^tolerance allowed for bounces, will be incremented if unsuccessful at 0
    
max_g_max = 2; %highest allowable value for maximum g forces
    
%Find the effects that changing L in the direction towards L_lim will
%have on the number of bounces and the maximum g's
%First, need to find the effects of increasing L
[~, ~, ~, ~, max_gforces_1] = Question_6_bungee(T, n, g, C, K, 1);
[~, ~, ~, ~, max_gforces_1000] = Question_6_bungee(T, n, g, C, K, 1000);
        
num_of_bounces_1 = find_number_of_bounces(n, g, C, K, 1);
num_of_bounces_1000 = find_number_of_bounces(n, g, C, K, 1000);
%using L = 1 and L = 1000 to guarantee a difference in no. of
%bounces and g forces
        
%compare these to the way L changes
if sign(max_gforces_1000 - max_gforces_1) == sign(L_lim - L);
    g_change_same = 1;
else
    g_change_same = 0;
end
if sign(num_of_bounces_1000 - num_of_bounces_1) == sign(L_lim - L)
    b_change_same = 1;
else
    b_change_same = 0;
end
        
[ideal_L, ideal_K] = Question_6_find_best_L(T, n, g, C, start_L, end_L, H, max_y_goal, goal_bounces, bounce_tolerance, max_g_max, g_change_same, b_change_same, start_K, end_K);  
while (ideal_L == L_lim) || (ideal_K == K_lim)
    bounce_tolerance = bounce_tolerance + 1;
    if bounce_tolerance < goal_bounces %shouldn't happen, but this (10)
    %^... is the last value that can be tolerated
        [ideal_L, ideal_K] = Question_6_find_best_L(T, n, g, C, start_L, end_L, H, max_y_goal, goal_bounces, bounce_tolerance, max_g_max, g_change_same, b_change_same, start_K, end_K);  
    else
        warning('Sorry, but the Parameters provided don''t have any better water touch possibilities.')
        [ideal_L, ideal_K] = Question_6_find_best_L(T, n, g, C, start_L, end_L, H, max_y_goal, goal_bounces, bounce_tolerance, max_g_max, g_change_same, b_change_same, start_K, end_K);  
        break
    end
end

end
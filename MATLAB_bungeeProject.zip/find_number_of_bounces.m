function num_of_bounces = find_number_of_bounces(n, g, C, K, L)
% num_of_bounces = find_number_of_bounces(T, n, g, C, K, L, H) performs Euler's method on
% the bungee jumping model, taking n steps from t = 0 to t = T.
% The initial conditions are y(0) = 0 and v(0) = 0.
% The inputs g, C, K, L, D and m are parameters from the model (see project description).
% g is the acceleration due to gravity (i.e. 9.8)
% m is the mass of the jumper
% C = c/m, where c is the drag coefficient when moving through the air
% K = k/m, where k is the spring constant of the bungee rope/cord
% L is the length of the rope, and H is the height of the jumping platform
%The output is the number of 'bounces' experienced by the jumper

%run the bungee function for the inputs provided, but with T=60 (to only
%calculate for 60 seconds)
[~, ybounce] = Question_6_bungee(60, n, g, C, K, L);
bounces = []; %create a vector to contain the times at which the jumper experiences bounces
[~, columns] = size(ybounce); %have to do this, otherwise problems occur with size having 2 dimensions
for time = 2:columns-1
    if ybounce(time) > ybounce(time+1)
        if ybounce(time) > ybounce(time-1)
            bounces(end + 1) = time;
        end
    end
end
[~, columns] = size(bounces);
num_of_bounces = columns;
end
    


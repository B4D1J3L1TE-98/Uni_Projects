function [ideal_L, ideal_K, ideal_k, whichVal] = Question_6_bisection(T, n, g, C, K, L, H, y, m)
%BISECTION Bisection method
%ideal_L is the ideal length of the rope for the Bungee jumper to only just
% touch the water, from the inputs
%ideal_k is the ideal spring constant k from the other values, which will
% be calculated if and only if 'ideal_L' isn't so ideal without changing k
%ideal_K is the ideal value of K from the other values, which will be
% calculated if and only if 'ideal_L' isn't so ideal without changing K
%ideal_K will be used to calculate ideal_k, as K is used in the
% Question_6_bungee function
%All three values will be necessary if 'ideal_L' isn't ideal by itself and
% 'ideal_K' also isn't ideal by itself
%whichVal is which value (out of L or K) should be changed to produce a
% water touch experience
%As it is pretty much guaranteed that the jumper doesn't already descend
% to (or below) water level, and that extending the rope by the jumper's
% minimum height above the water will result in the jumper being submerged
% too far, there should be no need to raise an error as an initial
% bracketing should be guaranteed
%y is the solution array y from Question 1 in the main m-file,
%modeuler_bungee

%(T, n, g, C, K, L) are the values necessary to run Question_6_bungee:
% [t, y, v, h, max_g_forces] = Question_6_bungee(T, n, g, C, K, L) performs Euler's method on
% the bungee jumping model, taking n steps from t = 0 to t = T.
% The initial conditions are y(0) = 0 and v(0) = 0.
% The inputs g, C, K and L are parameters from the model (see project description).
% g is the acceleration due to gravity (i.e. 9.8)
% m is the mass of the jumper (not necessary here, but explains C and K)
% C = c/m, where c is the drag coefficient when moving through the air
% K = k/m, where k is the spring constant of the bungee rope/cord
% L is the length of the rope
% The outputs are the time array t, the solution arrays y and v, the
% subinterval width h, and the maximum number of g-forces experienced by
% the jumper max_g_forces

%set unchanged values of K and k
ideal_K = K;
ideal_k = K*m;

start_L = L; % the initial bracketing for our bisection is (L, L+74-max(y)).
%L is the unmodified rope length

end_L = L+74-max(y); % the initial bracketing for our bisection is (L, L+74-max(y)). 
% L+74-max(y) is the rope length if it were just extended by the jumper's minimum height above the water 
% (which is obviously going to submerge the jumper too far, because the rope stretches/bounces)

ideal_L = (start_L + end_L)/2; %the initial value for ideal_L is halfway between start_L and end_L

%According to a quick google search, 80.7kg is the average weight of a
%human, which has been rounded down for this assignment (likely for
%convenience and simplicity.
%According to a second quick google search, the average heights for a
%man and a woman are 1.7m and 1.6m respectively. As we don't want the
%jumper to be submerged entirely (we want them to 'only just' touch the
%water), we should make an allowance of about 1.5m. This allows both
%the man and the woman to submerge part of their head, but doesn't
%invlove them drowning or being underwater for long enough to mess with
%the calculations (20cm is just under the average height of a
%human head)
    
%As such, the ideal maximum y is (H-1.5)m (minimum height above the water
%is 1.5m):
max_y_goal = H-1.5;

whichVal = 'L'; %L is the value to be changed (for now)
while (ideal_L ~= end_L) && (ideal_L ~= start_L)
    %Run the Question_6_bungee function to find the maximum y value for
    %each value of L
    [~, y_start, ~, ~] = Question_6_bungee(T, n, g, C, K, start_L);
    [~, y_ideal, ~, ~] = Question_6_bungee(T, n, g, C, K, ideal_L);
    
    if sign(max_y_goal - max(y_ideal)) == sign(max_y_goal - max(y_start))
        %^if the maximum y using the current ideal_L value is on the same
        %^side of the goal for max_y as the maximum y using the current
        %^start_L value
        start_L = ideal_L;
    else
        end_L = ideal_L;
    end
    ideal_L = (start_L + end_L)/2; %calculate new ideal_L value
end
[~, ~, ~, ~, max_gforces_at_ideal_L] = Question_6_bungee(T, n, g, C, K, ideal_L);
num_of_bounces_at_ideal_L = find_number_of_bounces(n, g, C, K, ideal_L);
if (max_gforces_at_ideal_L > 2) || (abs(num_of_bounces_at_ideal_L-10) > 1)
    %^ if the jumper will experience an unsafe amount of acceleration when only modifiying L
    %^ or if the number of bounces changes to either <9 or >11
    
    %Tell the user why changing the length of the rope won't be ideal:
    if ~(abs(num_of_bounces_at_ideal_L-10) > 1)
        %^ if the reason is solely the unsafe acceleration
        warning(['A water touch experience would be achieved by changing the length of the rope to ' num2str(ideal_L) ' metres, but this will produce an unsafe amount of acceleration (' num2str(max_gforces_at_ideal_L) 'g).'])
    elseif ~(max_gforces_at_ideal_L > 2)
        warning(['A water touch experience would be achieved by changing the length of the rope to ' num2str(ideal_L) ' metres, but this will change the number of bounces to ' num2str(num_of_bounces_at_ideal_L) ' bounces.'])
    else
        warning(['A water touch experience would be achieved by changing the length of the rope to ' num2str(ideal_L) ' metres, but this will produce an unsafe amount of acceleration (' num2str(max_gforces_at_ideal_L) 'g) and will also change the number of bounces to ' num2str(num_of_bounces_at_ideal_L) ' bounces.'])
    end
    whichVal = 'K'; %K is the value to be changed now, because changing L didn't work
    
    %calculate the appropriate spring constant for the rope using the
    %original L value
    start_K = K;
    multiplier = 2; %create a multiplier variable so that multiple values of K can be tested easily in code
    end_K = multiplier*K; %set a test value for K as it isn't immediately obvious 
    %whether a larger value for K will result in the jumper falling a longer or shorter distance
    
    %Calculate the outputs for each value of K
    [~, y_start, ~, ~] = Question_6_bungee(T, n, g, C, start_K, L);
    [~, y_end, ~, ~] = Question_6_bungee(T, n, g, C, end_K, L);
    while sign(max_y_goal - y_end) == sign(max_y_goal - y_start) 
        %^if the values of start_K and end_K don't result in y_start and
        %y_end bracketing max_y_goal
        if end_K > start_K
            end_K = start_K / multiplier; %make end_K smaller than start_K 
            %(start and end are just labels, not really indicative of which one is larger)
            multiplier = multiplier * 2; %increase the multiplier so that an 
            %infinite loop is avoided and values of K resulting a bracketing of the goal are found
        else
            end_K = start_K * multiplier; %make end_K greater than K
        end
        %Recalculate the outputs for each value of K
        [~, y_start, ~, ~] = Question_6_bungee(T, n, g, C, start_K, L);
        [~, y_end, ~, ~] = Question_6_bungee(T, n, g, C, end_K, L);
    end
    %Now that initial values for start_K and end_K have been found, the
    %bisection method can be applied
    ideal_K = (start_K + end_K) / 2;
    
    while (ideal_K ~= end_K) && (ideal_K ~= start_K)
    %Run the Question_6_bungee function to find the maximum y value for
    %each value of K
    [~, y_start, ~, ~] = Question_6_bungee(T, n, g, C, start_K, L);
    [~, y_ideal, ~, ~] = Question_6_bungee(T, n, g, C, ideal_K, L);
    
        if sign(max_y_goal - max(y_ideal)) == sign(max_y_goal - max(y_start))
            %^if the maximum y using the current ideal_K value is on the same
            %^side of the goal for max_y as the maximum y using the current
            %^start_K value
            start_K = ideal_K;
        else
            end_K = ideal_K;
        end
        ideal_K = (start_K + end_K)/2; %calculate new ideal_K value
    end
    [~, ~, ~, ~, max_gforces_at_ideal_K] = Question_6_bungee(T, n, g, C, ideal_K, L);
    ideal_k = ideal_K*m;
    if max_gforces_at_ideal_K > 2
        warning(['Maximum g forces are unsafe ' num2str(min(max_g_forces_at_ideal_K, max_gforces_at_ideal_L)) 'g'])
    else
        %Calculate number of bounces when using ideal_K
        num_of_bounces_at_ideal_K = find_number_of_bounces(n, g, C, ideal_K, L);
        if (max_gforces_at_ideal_K > 2)
               warning(['Modifying the spring constant or the length of the rope to allow for a water touch experience will result in an unsafe amount of acceleration (' num2str(max_gforces_at_ideal_K) 'g).']) 
        elseif (max_gforces_at_ideal_K < 1.8) || (abs(num_of_bounces_at_ideal_K-10) > 1)
            %^Allow 10% below 2g, OR if <9 or >11 bounces, or if above 2g
            
            %Tell the user why this 'ideal_K' is not so ideal:
            if ~(abs(num_of_bounces_at_ideal_K-10) > 1) 
                %^if reason for this not being an ideal solution is solely
                %^that less than 1.8g will be experienced
                warning(['Changing the spring constant to ' num2str(ideal_k) ' Newtons per metre will produce a water touch experience for the jumper, but will decrease the highest acceleration felt to ' num2str(max_gforces_at_ideal_K) 'g.'])
            elseif ~(max_gforces_at_ideal_K < 1.8)
                %^if reason for this not being an ideal solution is solely
                %^that the number of bounces will change
                warning(['Changing the spring constant to ' num2str(ideal_k) ' Newtons per metre will produce a water touch experience for the jumper, but will change the number of bounces to ' num2str(num_of_bounces_at_ideal_K) ' bounces.'])
            else %< if both the number of bounces changes and the maximum g forces decreases below 1.8
                warning(['Changing the spring constant to ' num2str(ideal_k) ' Newtons per metre will produce a water touch experience for the jumper, but will change the number of bounces to ' num2str(num_of_bounces_at_ideal_K) ' bounces and will decrease the highest acceleration felt to ' num2str(max_gforces_at_ideal_K) 'g.'])
            end
            
            %Need to change both K value and L value:
            whichVal = 'Both'; %neither 'L' nor 'K' is the sole value to be changed          
            
            %Call a function to find the ideal change to both L and K 
            %values:
            [ideal_L, ideal_K] = Question_6_change_both_values(T, n, g, C, K, L, H, max_y_goal, ideal_L, ideal_K);
            ideal_k = ideal_K * m;
        else 
            max_gforces_at_ideal_K
        end
    end
else
    max_gforces_at_ideal_L
end


end
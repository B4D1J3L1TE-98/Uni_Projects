function [p, x_at_goal_y] = bisection_bungee(xVals, yVals, goal, a, b)
%BISECTION Bisection method
% P = BISECTION_BUNGEE(H, D, a, b) returns the value where yVals(xVals)=goal 
% where goal is the value to be found for yVals(xVals), and [a, b] is the initial bracketing.
% An error is raised if [A,B] are not on opposite sides (sides being positive and negative) of the solution.

if sign(goal - yVals(a)) == sign(goal - yVals(b))
    error('a and b must be on opposite sides of the goal y Value.')
end

p = ((a+b) - mod((a+b), 2))/2; % compute the initial midpoint value (mod is used to make sure p is an integer)

while (yVals(p) ~= goal)
    if abs(a-b) <= 1
        p = a;
        break
    end
    p = ((a+b) - mod((a+b), 2))/2; % compute the midpoint value (mod is used to make sure p is an integer)
    if sign(goal - yVals(a)) == sign(goal - yVals(p)) %if a and p are both on the same side of the goal
        a = p;
    else
        b = p;
    end
end

x_at_goal_y = xVals(p);
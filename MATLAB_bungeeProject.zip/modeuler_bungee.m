function [t, y, v, h, A , Total_Distance] = modeuler_bungee(T, n, g, C, K, L, H, D, m)
% [t, y, v, h, A , Total_Distance] = modeuler_bungee(T, n, g, C, K, L, H, D) performs Euler's method on
% the bungee jumping model, taking n steps from t = 0 to t = T.
% The initial conditions are y(0) = 0 and v(0) = 0.
% The inputs g, C, K, L, H, D and m are parameters from the model (see project description).
% g is the acceleration due to gravity (i.e. 9.8)
% m is the mass of the jumper
% C = c/m, where c is the drag coefficient when moving through the air
% K = k/m, where k is the spring constant of the bungee rope/cord
% L is the length of the rope, H is the height of the jumping platform, 
% and D is the height of the 'deck'
% The outputs are the time array t, the solution arrays y and v, the
% subinterval width h, the acceleration array A, and the approximate total
% distance travelled by the jumper


% Calculate subinterval width h
h = T / n;

% Create time array t
t = 0:h:T;

% Initialise solution arrays y and v
y = zeros(1,n+1);
v = zeros(1,n+1);

% perform iterations
for j = 1:n
    %%%  f(t(j), w(j)) becomes the expression for acceleration
    %%%  (g - C*abs(v(j))*v(j) - max(0, K*(y(j) - L))):
    k1 = h*(g - C*abs(v(j))*v(j) - max(0, K*(y(j) - L)));
    
    %%%  substitute (v(j)+k1) for all (v(j)) because k2=f(t(j) + h, w(j) + k1), 
    %%%  so basically turning (w(j)) into (w(j)+k1) [the time array doesn't
    %%%  affect this]
    k2 = h*(g - C*(abs(v(j)+k1))*(v(j)+k1) - max(0, K*((y(j)) - L)));
    v(j+1) = v(j) + 1/2 * (k1 + k2);
    
    %%% the expression for y also changes
    %%% use formula: y(i+1)=y(i)+(h/2)[f(t(i), y(i))+f(t(i+1), y(i+1))]
             yk1 = v(j);
             yk2 = v(j+ 1);
             y(j+1) = y(j) + ((h/2) * (yk1 + yk2));
end

%added code to show velocity against time, these lines are 'commented out'
%%added code to show height above water, also 'commented out'
figure(1)
%plot(t, v, 'r'); % velocity
%hold on
%plot(t, y, 'g'); %%%% depth
plot(t, H-y, 'b'); %% 74=H, height
hold on
plot(t, t*0+H, 'c'); %% 74=H, to show height of platform
xlabel('Time (s)');
%ylabel('Jump Depth (m)');
%ylabel('Jumper''s Vertical Velocity (m/s)') % velocity
ylabel('Jumper''s Height Above Water (m)') %% height
%title('Figure 1: Plot of Jump Depth Against Time') %%%% depth
%title('Figure 1: Plot of Jumper''s Velocity Against Time') % velocity
title('Figure 1: Plot of Jumper''s Height Above Water') %% height
legend('Jumper''s Height (m)', 'Platform Height (m)')
%legend('Vertical Velocity (m/s)', 'Jump Depth (m)') % %%%% velocity, depth
%legend('Vertical Velocity (m/s)', 'Jumper''s Height Above Water (m)') % %%
%legend('Vertical Velocity (m/s)', 'Jump Depth (m)', 'Jumper''s Height Above Water(m)')

%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_
%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

%Question 2
figure(2)
plot(t, v, 'r'); % velocity against time
hold on
xlabel('Time (s)'); %label x axis as time
ylabel('Jumper''s Vertical Velocity (m/s)') %label y axis as velocity
title('Figure 2: Plot of Jumper''s Velocity Against Time') %title
%find the times at the maximum velocity in either direction
for time = 1:length(v);
    if v(time) == max(v);
        time_at_downwards_velocity_max = t(time)
    elseif v(time) == min(v);
        time_at_upwards_velocity_max = t(time)
    end
end
%Plot the greater maximum with an O, and the maximum in the opposite
%direction with an X
if abs(max(v)) - abs(min(v)) < 0 %if the maximum negative velocity is greater in magnitude than the maximum positive velocity
    maximum_speed = [num2str(abs(min(V))) 'm/s (upwards)']
    time_at_maximum_speed = [num2str(time_at_upwards_velocity_max) ' seconds']
    plot(time_at_downwards_velocity_max, max(v), 'gX')
    plot(time_at_upwards_velocity_max, min(v), 'gO')
    legend('Jumper''s Downwards Velocity', 'Jumper''s Maximum Downwards Velocity', 'Jumper''s Maximum Upwards Velocity (Higher in Magnitude)') %legend
else %if the maximum positive velocity is greater in magnitude than the maximum negative velocity
    maximum_speed = [num2str(abs(max(v))) 'm/s (downwards)']
    time_at_maximum_speed = [num2str(time_at_downwards_velocity_max) ' seconds']
    plot(time_at_downwards_velocity_max, max(v), 'gO')
    plot(time_at_upwards_velocity_max, min(v), 'gX')
    legend('Jumper''s Downwards Velocity', 'Jumper''s Maximum Downwards Velocity (Higher in Magnitude)', 'Jumper''s Maximum Upwards Velocity') %legend
end

%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_
%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

%Question 3 
%numerical differentiation 
A = zeros(1,n+1);
A(1) = 0 ;
for i = 2 : n 
    A(i) = (v(i+1) -  v(i-1)) / (2*h); %approximation for Acceleration, See chapter 5 
%approximating third derivative will require approximation of a further
%derivative, so we must accept an error of [ ((h^2)/6)*(f'''(c)) ]
end

maximum_positive_acceleration = max(A);
maximum_negative_acceleration = min(A);
if abs(maximum_positive_acceleration) - abs(maximum_negative_acceleration) < 0 %if the maximum negative acceleration is greater in magnitude than the maximum positive acceleration
    max_gforces = (abs(maximum_negative_acceleration))/(9.8) %calculate the maximum gforce
    highest_acceleration_magnitude_sign = -1; %then remember that the negative maximum has a higher magnitude
else %if the maximum positive acceleration is greater in magnitude than the maximum negative acceleration
    max_gforces = (abs(maximum_positive_acceleration))/(9.8) %calculate the maximum gforce
    highest_acceleration_magnitude_sign = 1; %then remember that the negative maximum has a higher magnitude
end

%test every value in A to find the index of the highest acceleration (by
%magnitude)
for time = 1:length(A)
    if A(time) == highest_acceleration_magnitude_sign * max_gforces * 9.8;
        time_at_highest_acceleration_magnitude = time*h %calculate the time in seconds at this point and store the value, also display it
    end
end


figure(3)
plot(t,A,'b')       %plot acceleration downwards
hold on
plot(t,(0-A),'r')   %plot acceleration upwards
legend('Acceleration Downwards', 'Acceleration Upwards') % add legend
title('Figure 3: Acceleration of the Jumper Over Time') % add title

%add axis labels:
xlabel('Time (s)')
ylabel('Acceleration (m/s)')

%plot maximum acceleration by magnitude as positive and negative (because
%acceleration is plotted in both directions)
plot(time_at_highest_acceleration_magnitude, max_gforces*9.8, 'gO')
plot(time_at_highest_acceleration_magnitude, max_gforces*(0-9.8), 'gO')

legend3 = ['Largest Acceleration by Magnitude (' num2str(max_gforces*9.8) ' m/s, or ' num2str(max_gforces) 'g)']; %create a string explaining that the latest plot is the maximum acceleration
legend('Acceleration Downwards', 'Acceleration Upwards', legend3) %update the legend

%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_
%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

%Question 4 
%numerical integration

end_time = (60/h)+1; %set end time (60 seconds)

%initialize sums
Sum_1 = 0;
Sum_2 = 0;

%absolute values will be used because we are computing distance (integral of speed), not displacement (integral of velocity)

%Compute summations
for i1 = 2:((end_time+1)/2) %same as ((n-1)/2)+1, which is what the value must be when translated to MATLAB code, as MATLAB doesn't count from 0
    Sum_1 = Sum_1 + abs(v(2*i1-2)); 
end
for i2 = 2:((end_time-1)/2)
    Sum_2 = Sum_2 + abs(v(2*i2-1));
end

%Calculate approximate Total Distance (using Simpson's rule as it is the more
%accurate method)
%Actual answer was found to be 292.2207m when adding up the values manually
Total_Distance = (h/3)*(abs(v(1))+4*Sum_1+2*Sum_2+abs(v(end_time)))

%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_
%-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_

% Question 5

t_at_deck_height = -1; %assign an arbitrary, impossible value to time at deck height
for time = 1:end_time
    if y(time) < (H-D)
        if y(time+1) > (H-D)
            %save x values
            x0 = time-1;
            x1 = time;
            x2 = time+1;
            x3 = time+2;
            break %exit the loop, as the times for y0,y1,y2,y3 have been found
        elseif y(time+1) == (H-D) %test if time at deck height has been found
            t_at_deck_height = y(time+1);
            time_when_first_at_deck_height = [num2str(t_at_deck_height*h) ' seconds'] %display time when jumper first reaches deck height
            break %exit the loop, as the time when the jumper first reaches the deck height has been found
        end
    end
end

% test if time at deck height has already been found (unlikely to happen, but still
% possible)
if t_at_deck_height >= 0
    time_when_first_at_deck_height = [num2str(t_at_deck_height*h) ' seconds'] %display time when jumper first reaches deck height
else
    % use Newton's divided difference form to compute first t at deck height
    Xvals = [x0, x1, x2, x3]; %create array of x values (time)
    Yvals = y(Xvals); %create array of y values using the x values
    
    Tvals = divided_differences(Xvals, Yvals); %create divided difference table
    xVals = x0:0.0001:x3; %create array of x values to find corresponding y values for (use 0.0001 as interval to have solution accurate to 4dp)
    
    yVals = divided_eval(Xvals, Tvals, xVals);
    
% % %    %% The following code, uncommented, would find and display the first value of t such that
% % %    %% y(t) = H-D
% % %       for index = 1:length(xVals)
% % %            if abs(yVals(index) - (H-D)) <= 0.00004
% % %               t_at_deck_height = xVals(index)
% % %               time_when_first_at_deck_height = [num2str(t_at_deck_height*h) ' seconds'] %display time when jumper first reaches deck height
% % %            end
% % %       end

    %use bisection method (new coding file as no anonymous function for f
    %was actually found by the program, so the coding file operates
    %without it)
    goal = H-D; % set 'goal' value
    a=1; %set a value
    b=(length(xVals)); %set b value
    [p, t_at_deck_height] = bisection_bungee(xVals, yVals, goal, a, b);
    time_when_first_at_deck_height = [num2str(t_at_deck_height*h) ' seconds'] %display time when jumper first reaches deck height
end

end